# hexEVAL watcher-engine (voorbeeldscript)
print('hexEVAL gestart. Wacht op pulses...')